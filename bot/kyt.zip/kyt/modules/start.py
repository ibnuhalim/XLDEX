from kyt import *

@bot.on(events.NewMessage(pattern=r"(?:.start|/start)$"))
@bot.on(events.CallbackQuery(data=b'start'))
async def start(event):
    inline = [
        [Button.inline("🔥PANEL CREATE ACCOUNT🔥", "menu")]
    ]
    
    sender = await event.get_sender()
    val = valid(str(sender.id))
    
    if val == "false":
        try:
            await event.answer("📵 Pinjam Dulu 100📵", alert=True)
        except:
            await event.reply("📵 Pinjam Dulu 100📵")
    
    elif val == "true":
        # Ambil data sistem
        sh = 'cat /etc/ssh/.ssh.db | grep "###" | wc -l'
        ssh = subprocess.check_output(sh, shell=True).decode("ascii").strip()

        vm = 'cat /etc/vmess/.vmess.db | grep "###" | wc -l'
        vms = subprocess.check_output(vm, shell=True).decode("ascii").strip()

        vl = 'cat /etc/vless/.vless.db | grep "###" | wc -l'
        vls = subprocess.check_output(vl, shell=True).decode("ascii").strip()

        tr = 'cat /etc/trojan/.trojan.db | grep "###" | wc -l'
        trj = subprocess.check_output(tr, shell=True).decode("ascii").strip()

        sdss = "cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g' | sed 's/\"//g'"
        namaos = subprocess.check_output(sdss, shell=True).decode("ascii").strip()

        ipvps = "curl -s ipv4.icanhazip.com"
        ipsaya = subprocess.check_output(ipvps, shell=True).decode("ascii").strip()

        citsy = "cat /etc/xray/city"
        city = subprocess.check_output(citsy, shell=True).decode("ascii").strip()

        msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
**☘️🔰 PREMIUM PANEL MENU 🔰☘️**
━━━━━━━━━━━━━━━━━━━━━━━ 
🔰 **» OS     :** `{namaos}`
🔰 **» CITY   :** `{city}`
🔰 **» DOMAIN :** `{DOMAIN}`
🔰 **» IP VPS :** `{ipsaya}`
━━━━━━━━━━━━━━━━━━━━━━━
"""

        # Kirim atau edit pesan
        try:
            await event.edit(msg, buttons=inline)
        except:
            await event.reply(msg, buttons=inline)